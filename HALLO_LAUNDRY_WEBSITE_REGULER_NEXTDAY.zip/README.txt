HALLO LAUNDRY WEBSITE

CARA MENJALANKAN
1. Ekstrak file ZIP.
2. Simpan index.html, style.css, dan script.js dalam satu folder yang sama.
3. Buka index.html dengan browser (Chrome, Edge, Firefox).
4. Website dapat berjalan tanpa server karena menggunakan HTML, CSS, dan JavaScript biasa.

CARA MENGUBAH WEBSITE
- Nama, teks, layanan, dan harga: edit index.html.
- Warna, ukuran, layout, dan tampilan: edit style.css.
- Kalkulator, menu HP, dan form WhatsApp: edit script.js.

DATA YANG SUDAH DIMASUKKAN
- HALLO LAUNDRY
- WhatsApp: 0857-6536-3475
- Area: Botania, Batam
- Harga reguler per kg:
  Cuci Komplit Rp7.000
  Cuci Lipat Rp6.000
  Setrika Saja Rp5.000
  Cuci Saja Rp4.000
  Cuci Kering Rp5.000
  Lipat Saja Rp2.000

CATATAN
- Harga express dan treatment khusus tidak dibuat-buat; pelanggan diarahkan untuk konfirmasi melalui WhatsApp.
- Gambar hero dibuat dengan CSS, jadi website tetap tampil tanpa file gambar tambahan.
- Font Google membutuhkan koneksi internet; jika offline, website memakai font cadangan.
